/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Reponse;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import services.CRUDReponse;

/**
 * FXML Controller class
 *
 * @author lenovo
 */
public class AfficherReponsesController implements Initializable {

    @FXML
    private TableView<Reponse> tableReponse;
    @FXML
    private TableColumn<?,?> idrep;
    @FXML
    private TableColumn<?,?> idrec;
    @FXML
    private TableColumn<?,?> rep;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        afficherReponses();
    }    
    
    

    private void afficherReponses() {
       CRUDReponse Rp = new CRUDReponse();
        ObservableList<Reponse> ReponseList = (ObservableList<Reponse>) Rp.afficherReponses2();

       
        
        idrep.setCellValueFactory(new PropertyValueFactory<>("id_Reponse"));
        idrec.setCellValueFactory(new PropertyValueFactory<>("id_Reclamation"));
       rep.setCellValueFactory(new PropertyValueFactory<>("description_Reponse"));
        tableReponse.setItems(ReponseList);
    }
}
